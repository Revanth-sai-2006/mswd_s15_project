import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { FunState } from './components/FunState'
import { About } from './components/About'
import { Home } from './components/Home'
import { Layout } from './components/Layout'

function App() {

  return (
    <>
     {/*<FunState></FunState>*/}
     {/* <About></About>  */}
     {/*<Home></Home>*/}
     <Layout></Layout>
    </>
  )
}

export default App
