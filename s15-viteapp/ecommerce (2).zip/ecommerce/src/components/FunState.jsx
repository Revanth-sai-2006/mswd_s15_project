import React, { useState } from 'react'
import Button from '@mui/material/Button'

export const FunState = () => {
    const [count,setCount]=useState(0);
    function incrementCount(){
      
        setCount(
            count+1
        )
    }
    function decrementCount(){
        setCount(
            count-1
        )
    }
  return (
    <div >
        <h1>Count: {count }</h1>
        <Button variant="contained" onClick={()=>incrementCount()}>Increment</Button>
        <Button variant="outlined" onClick={()=>decrementCount()}>Decrement</Button>

    </div>
  )
}
