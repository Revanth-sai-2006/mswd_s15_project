import React from 'react'

export const About = () => {
  return (
    <div>
        <h1></h1>
    </div>
  )
}
