import React from 'react'
import'./Layout.css'
import { Route,Routes,Link } from 'react-router-dom'
import { Home } from './Home'
import { About } from './About'
import Login from './Login'
import Register from './Register'
import CoursesList from './CoursesList'
import { FunState } from './FunState'
import ResponsiveAppBar from './ResponsiveAppBar'
export const Layout = () => {
  return (
    <div className='container'>
        <div className='header'>
            <ResponsiveAppBar/>
            {/* <nav>
                <Link to='/'>Home</Link>
                <Link to='/about'>About</Link>
                <Link to='/Login'>Login</Link>
                <Link to='/Register'>Register</Link>
                <Link to='/CoursesList'>CoursesList</Link>
                
            </nav> */}
        </div>
        <div className='lsb'>LSB
        <Routes>
            <Route path='CoursesList' element={<CoursesList/>}/>
        </Routes>
        </div>
        <div className='main'>Main Content
            <Routes>
                <Route path='/' element={<Home/>}/>
                <Route path='main' element={<About/>}/>
                <Route path='Login' element={<Login/>}/>
                <Route path='Register' element={<Register/>}/>
                
            </Routes>
        </div>
        <div className='footer'>Footer</div>

    </div>
  )
}
